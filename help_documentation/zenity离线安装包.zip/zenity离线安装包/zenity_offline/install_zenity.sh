#!/bin/bash

# 统信ARM 离线安装 zenity（解决无法选择文件夹）

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

notify-send "开始离线安装 zenity 依赖"

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN}     正在安装所有依赖包...${NC}"
echo -e "${GREEN}=============================================${NC}"

cd "$(dirname "$0")/DEBS"

# 安装所有deb
sudo dpkg -i *.deb

# 修复依赖（统信必备）
sudo apt-get -f install -y

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN}     安装完成！${NC}"
echo -e "${GREEN}     现在可以选择文件夹了${NC}"
echo -e "${GREEN}=============================================${NC}"

notify-send "zenity 安装完成！"
