#!/bin/bash
if grep -qE "20211023|2203" /etc/.kyinfo; then
    notify-send "系统版本符合要求，开始安装驱动"
    sudo dpkg -i Wayland/*.deb
    sleep 1
    sudo dpkg -i hw-mali-valhall-r23_1.3.4_arm64.deb
    sleep 1
    notify-send "安装驱动结束，请重启机器"
    
else
    notify-send "系统版本不符合要求，请确认系统版本"
fi
